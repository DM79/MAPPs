/*!
 * This file is part of App Builder
 * For licenses information see App Builder help
 * �2016 App Builder - https://www.davidesperalta.com
 */

window.App.Plugins.SendSMS = function() {

  /* Private plugin's stuff */

  var
    setEventVariables = function(error, message) {
      window.App.RootScope.SendSMSError = error;
      window.App.RootScope.SendSMSMessage = message;
    };

  /* Public interface: actions exposed by the plugin */

  return {

    SendSMS: function(number, message) {

      if (angular.isUndefined(window.sms)) {
        if (angular.isFunction(window.App.Scope.SendSMSErrorEvent)) {
          setEventVariables('-1', '');
          window.App.Scope.SendSMSErrorEvent();
        }
        return;
      }

      sms.sendMessage({
        phoneNumber: number,
        textMessage: message
      },
      function(message) {
        if (angular.isFunction(window.App.Scope.SendSMSSuccessEvent)) {
          setEventVariables('', message);
          window.App.Scope.SendSMSSuccessEvent();
        }
      },
      function(error) {
        if (angular.isFunction(window.App.Scope.SendSMSErrorEvent)) {
          setEventVariables(error, '');
          window.App.Scope.SendSMSErrorEvent();
        }
      });
    },

    /* Optional plugin's events (called by App Builder) */

    PluginSetupEvent: function() {
      // Nothing to do here
    },

    PluginAppReadyEvent: function() {
      // Nothing to do here
    },

    PluginDocumentReadyEvent: function() {
      // Nothing to do here
    }
  };
};
